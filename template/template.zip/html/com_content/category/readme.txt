/* DETALHAMENTO DE CUSTOMIZAÇÃO
 * Objeto:	VIEW 'CATEGORY' -> BLOG
 * data:	13/06/2013
 * autor:	Ivo Junior
*/

IMPORTANTE:
O arquivo 'blog.xml' deve ser enviado para o diretório 'components/com_content/views/category/tmpl' para que possa ser reconhecido como layout alternativo nas configurações do sistema de conteúdo. Sendo assim, sempre que atualizar o arquivo, lembrar de enviá-lo para atualizar o arquivo válido.