<div class="field-attach">
	<ul class="gallery gal[FIELD_ID] clearfix">
	    [LINES]
	</ul>
</div>