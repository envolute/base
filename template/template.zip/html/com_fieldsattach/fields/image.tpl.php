<div id="cel_[ARTICLE_ID]" class="field-attach image field_[FIELD_ID]">
    <img src="[URL]" title = "[TITLE]" alt="[TITLE]" />
</div>
 