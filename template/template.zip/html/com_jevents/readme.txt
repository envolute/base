CUSTOM	-> 03/04/2013

// CUSTOMIZAÇÃO DO JEVENTS
Não existe nenhuma customização direta que seja realmente relevante. Apenas em relação as imagens, onde algumas são chamadas diretamente do componente. Sendo assim, as imagens em 'base/html/com_jevents/assets/images' podem ou devem ser copiadas diretamente para o tema 'default' do componente em 'components/com_jevents/view/assets/images'.
Um exemplo são as setas para navegar na div 'navigation' do componente que foram customizadas para um modelo mais atual. Porém, se forem carregadas as originais já sabemos que as imagens não foram copiadas para o componente.