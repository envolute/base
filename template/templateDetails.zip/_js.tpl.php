<?php
defined('_JEXEC') or die;

// CHOSEN -> Carrega por default
JHtml::_('formbehavior.chosen', 'select:not(.no-chosen)');

?>

<!-- load javascript -->
<script type="text/javascript" src="templates/base/js/default.js"></script>
<?php if($loadDev) echo '<script type="text/javascript" src="templates/base/_dev/custom.js"></script>'; ?>

<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
	<script src="templates/base/core/libs/js/browser/html5shiv-printshiv.js"></script>
<![endif]-->
