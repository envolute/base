<div id="cel_[FIELD_ID]" class="field-attach">
    <span class="title">[TITLE]</span>
    <span class="value">
    	<ul class="listval">[LINES]</ul>
    </span>
</div>

 
 