<li class="value_[VALUE] cont_[CONT]">[TITLE]</li> 

 
 