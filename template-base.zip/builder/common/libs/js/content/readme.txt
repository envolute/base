/* FONTSIZE
 * Tipo:	CUSTOMIZAÇÃO
 * data:	21/08/2013
 * autor:	Ivo Junior
*/

Esse script é uma adaptação do...
/*
	FontSize for jQuery (version 1.1)
	Copyright (c) 2009 Ramon Victor
	http://www.ramonvictor.com/plugin-font-size-jquery
	
	Licensed under the MIT license:
		http://www.opensource.org/licenses/mit-license.php

	Any and all use of this script must be accompanied by this copyright/license notice in its present form.
*/
para o Template Base.

RECURSOS ADICIONAIS:
1. Bootstrap: customização do estilo utilizando classes do Bootstrap

ALTERAÇÕES:
Nenhuma

OBS:
Nenhuma
