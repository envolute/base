// SCRIPTS CUSTOMIZADOS DO PROJETO

//JQUERY
jQuery(function() {

	// EVENTOS RESPONSIVOS

		window.customResponsive = function () {

			// --

		};
		// CHAMADA DA FUNÇÃO
		customResponsive();
		jQuery(window).resize(function() { customResponsive(); }); // ON RESIZE

});
