<li><a href="[URL1]" class="set-modal" title="[TITLE]" rel="gal_[ARTICLE_ID]"><img src="[URL1]" alt="[TITLE]" /></a></li>
 