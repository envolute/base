<?php
defined('_JEXEC') or die;

// CHOSEN -> Carrega por default
JHtml::_('formbehavior.chosen', 'select:not(.no-chosen)');

?>
