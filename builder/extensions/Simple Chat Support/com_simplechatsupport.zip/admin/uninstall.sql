drop table IF EXISTS `#__simplechatsupport_message`;
drop table IF EXISTS `#__simplechatsupport_chat`;
drop table IF EXISTS `#__simplechatsupport_template`;
drop table IF EXISTS `#__simplechatsupport_status`;