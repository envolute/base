<?php 
/*@module mod_simplechatsupport */
defined('_JEXEC') or die;

// INIT JQUERY
$script = '
	jQuery.noConflict();
	jQuery(function() {
';

$script .= ($status) ? 'jQuery("body").addClass("support-on");' : 'jQuery("body").addClass("support-off");';

$style = (!$params->get('mobile')) ? '@media(max-width: 767px) { #simplechatsupport-widget { display: none; } }' : '';

$style .= '
	/*SIMPLE CHAT SUPPORT*/
	#simplechatsupport-widget {
		position: fixed;
		'.$params->get('vertical_position', 'bottom').': '.$params->get('vertical_distance', 0).'px;
		'.$params->get('horizontal_position', 'bottom').': '.$params->get('horizontal_distance', 10).'px;
		width: 300px;
		-webkit-border-radius: 4px 4px 0 0;
			border-radius: 4px 4px 0 0;
		-webkit-box-shadow: 0 0 6px 1px rgba(0,0,0,0.1);
			box-shadow: 0 0 6px 1px rgba(0,0,0,0.1);
		overflow: hidden;
		z-index: 9999;
	}
	#simplechatsupport-header {
		display: block;
		padding: 10px 15px 5px;
		color: '.$params->get('header_color_default', '#fff').';
		font-size: 1.2em;
		background-color: '.$params->get('header_background_default', '#f80').';
		background-image: url("'.JURI::base().'/modules/mod_simplechatsupport/assets/arrows-white.png");
		background-repeat: no-repeat;
		background-position: 275px -510px;
	}
	#simplechatsupport-widget.active #simplechatsupport-header {
		background-position: 275px -562px;
	}
	#simplechatsupport-widget.call #simplechatsupport-header {
		color: '.$params->get('header_color_call', '#fff').';
		background-color: '.$params->get('header_background_call', '#0d0').';
	}
	#simplechatsupport-container {
		padding: 5px 0 0 2px;
		background: #fff;
	}
';

$script .= '
	jQuery("#simplechatsupport-header").click(function() {
		jQuery("#simplechatsupport-widget").removeClass("call").toggleClass("active");
		jQuery("#simplechatsupport-container").slideToggle();
	});
';
// END JQUERY
$script .= '});';

if($params->get('css')) $style .= $params->get('css');
if($params->get('script')) $script .= $params->get('script');

$doc->addStyleDeclaration($style);
$doc->addScriptDeclaration($script);

if (($status && $params->get('type') != 0) || (!$status && $params->get('type') == 2)):
	$w = ($user->guest) ? '480px' : ($status ? '430px' : '320px');
	echo '
	<!-- Simple Chat Support -->
	<div id="simplechatsupport-widget">
		<a id="simplechatsupport-header" href="#">
			'.$params->get('header', JText::_('MOD_SIMPLECHATSUPPORT_HEADER_DEFAULT')).'
		</a>
		<div id="simplechatsupport-container" style="display:none;">
			<iframe width="100%" height="'.$w.'" frameborder="0" src="index.php?option=com_simplechatsupport&view=chat&ml=1&widget=1" allowfullscreen="true"></iframe>
		</div>
	</div>
	';
endif;
?>