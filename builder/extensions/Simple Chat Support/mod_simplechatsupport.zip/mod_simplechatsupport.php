<?php 
/*@module mod_simplechatsupport */
defined('_JEXEC') or die;

$doc = JFactory::getDocument();
$user = JFactory::getUser();

//VERIFY SUPPORT BASE ON/OFF
include_once JPATH_BASE.'/components/com_simplechatsupport/getStatus.php';
$status = statusChat::getStatus();

require JModuleHelper::getLayoutPath('mod_simplechatsupport', 'default');

?>